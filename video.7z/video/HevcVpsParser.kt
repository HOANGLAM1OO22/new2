package com.example.transition.video

import android.util.Log

object HevcVpsParser {

    fun parse(vpsNal: ByteArray) {
        // skip: 00 00 00 01 + 2-byte HEVC NAL header
        val rbsp = removeEmulationBytes(vpsNal.copyOfRange(6, vpsNal.size))
        val br = BitReader(rbsp)

        val vpsId = br.readBits(4)
        val baseLayerInternal = br.readBits(1) == 1
        val baseLayerAvailable = br.readBits(1) == 1
        val maxLayersMinus1 = br.readBits(6)
        val maxSubLayersMinus1 = br.readBits(3)
        val temporalIdNesting = br.readBits(1) == 1

        parseProfileTierLevel(br, maxSubLayersMinus1)

        val subLayerOrderingInfoPresent = br.readBits(1) == 1

        Log.i(
            "HEVC-VPS", """
            vps_id=$vpsId
            base_layer_internal=$baseLayerInternal
            base_layer_available=$baseLayerAvailable
            max_layers=${maxLayersMinus1 + 1}
            max_sub_layers=${maxSubLayersMinus1 + 1}
            temporal_id_nesting=$temporalIdNesting
            sub_layer_ordering_info_present=$subLayerOrderingInfoPresent
        """.trimIndent()
        )
    }

    private fun parseProfileTierLevel(br: BitReader, maxSubLayersMinus1: Int) {
        br.readBits(2) // profile_space
        br.readBits(1) // tier_flag
        val profileIdc = br.readBits(5)

        br.readBits(32) // compatibility flags
        br.readBits(48) // constraint flags
        val levelIdc = br.readBits(8)

        val subLayerProfilePresent = BooleanArray(maxSubLayersMinus1)
        val subLayerLevelPresent = BooleanArray(maxSubLayersMinus1)

        for (i in 0 until maxSubLayersMinus1) {
            subLayerProfilePresent[i] = br.readBits(1) == 1
            subLayerLevelPresent[i] = br.readBits(1) == 1
        }

        if (maxSubLayersMinus1 > 0) {
            repeat(8 - maxSubLayersMinus1) {
                br.readBits(2)
            }
        }

        for (i in 0 until maxSubLayersMinus1) {
            if (subLayerProfilePresent[i]) {
                br.readBits(2)
                br.readBits(1)
                br.readBits(5)
                br.readBits(32)
                br.readBits(48)
            }
            if (subLayerLevelPresent[i]) {
                br.readBits(8)
            }
        }

        Log.i(
            "HEVC-VPS",
            "profile_idc=$profileIdc level_idc=$levelIdc"
        )
    }

    private fun removeEmulationBytes(data: ByteArray): ByteArray {
        val out = ArrayList<Byte>()
        var i = 0
        while (i < data.size) {
            if (i + 2 < data.size &&
                data[i] == 0.toByte() &&
                data[i + 1] == 0.toByte() &&
                data[i + 2] == 3.toByte()
            ) {
                out.add(0)
                out.add(0)
                i += 3
            } else {
                out.add(data[i])
                i++
            }
        }
        return out.toByteArray()
    }
}
