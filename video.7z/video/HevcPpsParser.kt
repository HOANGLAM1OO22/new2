package com.example.transition.video

import android.util.Log

object HevcPpsParser {

    fun parse(ppsNal: ByteArray) {
        // skip: 00 00 00 01 + 2-byte HEVC NAL header
        val rbsp = removeEmulationBytes(ppsNal.copyOfRange(6, ppsNal.size))
        val br = BitReader(rbsp)

        val ppsId = br.readUE()
        val spsId = br.readUE()

        val dependentSliceSegmentsEnabled = br.readBits(1) == 1
        val outputFlagPresent = br.readBits(1) == 1
        val numExtraSliceHeaderBits = br.readBits(3)
        val signDataHidingEnabled = br.readBits(1) == 1
        val cabacInitPresent = br.readBits(1) == 1

        Log.i(
            "HEVC-PPS", """
            pps_id=$ppsId
            sps_id=$spsId
            dependent_slice_segments=$dependentSliceSegmentsEnabled
            output_flag_present=$outputFlagPresent
            num_extra_slice_header_bits=$numExtraSliceHeaderBits
            sign_data_hiding=$signDataHidingEnabled
            cabac_init_present=$cabacInitPresent
        """.trimIndent()
        )
    }

    private fun removeEmulationBytes(data: ByteArray): ByteArray {
        val out = ArrayList<Byte>()
        var i = 0
        while (i < data.size) {
            if (i + 2 < data.size &&
                data[i] == 0.toByte() &&
                data[i + 1] == 0.toByte() &&
                data[i + 2] == 3.toByte()
            ) {
                out.add(0)
                out.add(0)
                i += 3
            } else {
                out.add(data[i])
                i++
            }
        }
        return out.toByteArray()
    }
}
