package com.example.transition.video

import android.util.Log

object AvcPpsParser {

    fun parse(ppsNal: ByteArray) {
        val rbsp = removeEmulationBytes(ppsNal.copyOfRange(5, ppsNal.size))
        val br = BitReader(rbsp)

        val ppsId = br.readUE()
        val spsId = br.readUE()
        val cabac = br.readBits(1) == 1

        Log.i(
            "AVC-PPS",
            "pps_id=$ppsId sps_id=$spsId cabac=$cabac"
        )
    }

    fun removeEmulationBytes(data: ByteArray): ByteArray {
        val out = ArrayList<Byte>()
        var i = 0
        while (i < data.size) {
            if (i + 2 < data.size && data[i] == 0.toByte()
                && data[i + 1] == 0.toByte()
                && data[i + 2] == 3.toByte()
            ) {
                out.add(0)
                out.add(0)
                i += 3
            } else {
                out.add(data[i])
                i++
            }
        }
        return out.toByteArray()
    }
}
