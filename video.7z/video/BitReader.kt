package com.example.transition.video

class BitReader(private val data: ByteArray) {
    private var bitPos = 0

    fun readBits(n: Int): Int {
        var value = 0
        repeat(n) {
            val bytePos = bitPos / 8
            val shift = 7 - (bitPos % 8)
            value = (value shl 1) or ((data[bytePos].toInt() shr shift) and 1)
            bitPos++
        }
        return value
    }

    fun readUE(): Int {
        var zeros = 0
        while (readBits(1) == 0) zeros++
        return (1 shl zeros) - 1 + readBits(zeros)
    }

    fun readSE(): Int {
        val codeNum = readUE()
        return if (codeNum % 2 == 0) {
            -(codeNum / 2)
        } else {
            (codeNum + 1) / 2
        }
    }
}
