package com.example.transition.video

import android.util.Log

object AvcSpsParser {

    fun parse(spsNal: ByteArray) {
        // skip 00 00 00 01 + 1-byte AVC NAL header
        val rbsp = removeEmulationBytes(spsNal.copyOfRange(5, spsNal.size))
        val br = BitReader(rbsp)

        val profileIdc = br.readBits(8)
        val constraintFlags = br.readBits(8)
        val levelIdc = br.readBits(8)
        val spsId = br.readUE()

        var chromaFormatIdc = 1
        if (profileIdc in listOf(100,110,122,244,44,83,86,118,128,138,144)) {
            chromaFormatIdc = br.readUE()
            if (chromaFormatIdc == 3) br.readBits(1)
            br.readUE() // bit_depth_luma_minus8
            br.readUE() // bit_depth_chroma_minus8
            br.readBits(1)
            if (br.readBits(1) == 1) {
                // scaling matrices – usually absent
            }
        }

        br.readUE() // log2_max_frame_num_minus4
        val pocType = br.readUE()
        if (pocType == 0) {
            br.readUE()
        } else if (pocType == 1) {
            br.readBits(1)
            br.readSE()
            br.readSE()
            repeat(br.readUE()) { br.readSE() }
        }

        br.readUE() // max_num_ref_frames
        br.readBits(1)

        val picWidthInMbsMinus1 = br.readUE()
        val picHeightInMapUnitsMinus1 = br.readUE()
        val frameMbsOnlyFlag = br.readBits(1)
        if (frameMbsOnlyFlag == 0) br.readBits(1)

        br.readBits(1)

        var cropLeft = 0
        var cropRight = 0
        var cropTop = 0
        var cropBottom = 0
        if (br.readBits(1) == 1) {
            cropLeft = br.readUE()
            cropRight = br.readUE()
            cropTop = br.readUE()
            cropBottom = br.readUE()
        }

        val width = (picWidthInMbsMinus1 + 1) * 16 -
                (cropLeft + cropRight) * 2
        val height = (picHeightInMapUnitsMinus1 + 1) * 16 -
                (cropTop + cropBottom) * 2

        Log.i(
            "AVC-SPS", """
            profile_idc=$profileIdc
            level_idc=$levelIdc
            sps_id=$spsId
            chroma_format=4:2:0
            width=$width
            height=$height
        """.trimIndent()
        )
    }

    private fun cropUnitX(chroma: Int) = if (chroma == 0 || chroma == 3) 1 else 2
    private fun cropUnitY(chroma: Int, frameOnly: Int) =
        if (chroma == 0) 2 - frameOnly else 2 * (2 - frameOnly)

    private fun avcChroma(idc: Int) =
        when (idc) {
            0 -> "Monochrome"
            1 -> "4:2:0"
            2 -> "4:2:2"
            3 -> "4:4:4"
            else -> "Unknown"
        }

    fun removeEmulationBytes(data: ByteArray): ByteArray {
        val out = ArrayList<Byte>()
        var i = 0
        while (i < data.size) {
            if (i + 2 < data.size && data[i] == 0.toByte()
                && data[i + 1] == 0.toByte()
                && data[i + 2] == 3.toByte()
            ) {
                out.add(0)
                out.add(0)
                i += 3
            } else {
                out.add(data[i])
                i++
            }
        }
        return out.toByteArray()
    }
    fun parseAndReturn(spsNal: ByteArray): AvcSpsInfo {
        // skip 00 00 00 01 + 1-byte AVC NAL header
        val rbsp = removeEmulationBytes(spsNal.copyOfRange(5, spsNal.size))
        val br = BitReader(rbsp)

        val profileIdc = br.readBits(8)
        br.readBits(8) // constraint flags
        val levelIdc = br.readBits(8)
        val spsId = br.readUE()

        var chromaFormatIdc = 1
        if (profileIdc in listOf(100,110,122,244,44,83,86,118,128,138,144)) {
            chromaFormatIdc = br.readUE()
            if (chromaFormatIdc == 3) {
                br.readBits(1) // separate_colour_plane_flag
            }
            br.readUE() // bit_depth_luma_minus8
            br.readUE() // bit_depth_chroma_minus8
            br.readBits(1) // qpprime_y_zero_transform_bypass_flag
            if (br.readBits(1) == 1) {
                // seq_scaling_matrix_present_flag (rare, safe to skip)
            }
        }

        br.readUE() // log2_max_frame_num_minus4
        val pocType = br.readUE()
        if (pocType == 0) {
            br.readUE()
        } else if (pocType == 1) {
            br.readBits(1)
            br.readSE()
            br.readSE()
            repeat(br.readUE()) { br.readSE() }
        }

        br.readUE() // max_num_ref_frames
        br.readBits(1) // gaps_in_frame_num_value_allowed_flag

        val picWidthInMbsMinus1 = br.readUE()
        val picHeightInMapUnitsMinus1 = br.readUE()

        val frameMbsOnlyFlag = br.readBits(1)
        if (frameMbsOnlyFlag == 0) {
            br.readBits(1) // mb_adaptive_frame_field_flag
        }

        br.readBits(1) // direct_8x8_inference_flag

        var cropLeft = 0
        var cropRight = 0
        var cropTop = 0
        var cropBottom = 0

        if (br.readBits(1) == 1) { // frame_cropping_flag
            cropLeft = br.readUE()
            cropRight = br.readUE()
            cropTop = br.readUE()
            cropBottom = br.readUE()
        }

        val width = (picWidthInMbsMinus1 + 1) * 16 -
                (cropLeft + cropRight) * cropUnitX(chromaFormatIdc)

        val height = (2 - frameMbsOnlyFlag) *
                (picHeightInMapUnitsMinus1 + 1) * 16 -
                (cropTop + cropBottom) * cropUnitY(chromaFormatIdc, frameMbsOnlyFlag)

        return AvcSpsInfo(
            spsId = spsId,
            profileIdc = profileIdc,
            levelIdc = levelIdc,
            chromaFormatIdc = chromaFormatIdc,
            chromaFormat = avcChroma(chromaFormatIdc),
            width = width,
            height = height,
            frameMbsOnlyFlag = frameMbsOnlyFlag
        )
    }

}
