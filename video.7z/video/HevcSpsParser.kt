package com.example.transition.video

import android.util.Log

object HevcSpsParser {

    fun parse(spsNal: ByteArray) {
        // skip: 00 00 00 01 + 2-byte nal header
        val rbsp = removeEmulationBytes(spsNal.copyOfRange(6, spsNal.size))
        val br = BitReader(rbsp)

        val spsVideoParameterSetId = br.readBits(4)
        val maxSubLayersMinus1 = br.readBits(3)
        br.readBits(1) // sps_temporal_id_nesting_flag

        parseProfileTierLevel(br, maxSubLayersMinus1)

        val spsId = br.readUE()

        val chromaFormatIdc = br.readUE()
        if (chromaFormatIdc == 3) {
            br.readBits(1) // separate_colour_plane_flag
        }

        val picWidthInLumaSamples = br.readUE()
        val picHeightInLumaSamples = br.readUE()

        var confLeft = 0
        var confRight = 0
        var confTop = 0
        var confBottom = 0

        if (br.readBits(1) == 1) { // conformance_window_flag
            confLeft = br.readUE()
            confRight = br.readUE()
            confTop = br.readUE()
            confBottom = br.readUE()
        }

        val subWidthC = if (chromaFormatIdc == 1 || chromaFormatIdc == 2) 2 else 1
        val subHeightC = if (chromaFormatIdc == 1) 2 else 1

        val width = picWidthInLumaSamples - (confLeft + confRight) * subWidthC
        val height = picHeightInLumaSamples - (confTop + confBottom) * subHeightC

        Log.i(
            "HEVC-SPS", """
            sps_id=$spsId
            chroma_format=${hevcChroma(chromaFormatIdc)}
            width=$width
            height=$height
            max_sub_layers=$maxSubLayersMinus1
        """.trimIndent()
        )
    }
    fun parseAndReturn(spsNal: ByteArray): HevcSpsInfo {
        // skip: 00 00 00 01 + 2-byte HEVC NAL header
        val rbsp = removeEmulationBytes(spsNal.copyOfRange(6, spsNal.size))
        val br = BitReader(rbsp)

        val spsVideoParameterSetId = br.readBits(4)
        val maxSubLayersMinus1 = br.readBits(3)
        br.readBits(1) // sps_temporal_id_nesting_flag

        // ---- profile_tier_level() ----
        val profileTier = parseProfileTierLevelAndReturn(br, maxSubLayersMinus1)

        val spsId = br.readUE()

        val chromaFormatIdc = br.readUE()
        if (chromaFormatIdc == 3) {
            br.readBits(1) // separate_colour_plane_flag
        }

        val picWidthInLumaSamples = br.readUE()
        val picHeightInLumaSamples = br.readUE()

        var confLeft = 0
        var confRight = 0
        var confTop = 0
        var confBottom = 0

        if (br.readBits(1) == 1) { // conformance_window_flag
            confLeft = br.readUE()
            confRight = br.readUE()
            confTop = br.readUE()
            confBottom = br.readUE()
        }

        val subWidthC = if (chromaFormatIdc == 1 || chromaFormatIdc == 2) 2 else 1
        val subHeightC = if (chromaFormatIdc == 1) 2 else 1

        val width = picWidthInLumaSamples - (confLeft + confRight) * subWidthC
        val height = picHeightInLumaSamples - (confTop + confBottom) * subHeightC

        return HevcSpsInfo(
            spsId = spsId,
            profileIdc = profileTier.profileIdc,
            levelIdc = profileTier.levelIdc,
            chromaFormat = hevcChroma(chromaFormatIdc),
            width = width,
            height = height,
            maxSubLayersMinus1 = maxSubLayersMinus1
        )
    }

    private fun parseProfileTierLevel(br: BitReader, maxSubLayersMinus1: Int) {
        br.readBits(2) // general_profile_space
        br.readBits(1) // general_tier_flag
        val profileIdc = br.readBits(5)

        br.readBits(32) // general_profile_compatibility_flags
        br.readBits(48) // general_constraint_indicator_flags
        val levelIdc = br.readBits(8)

        val subLayerProfilePresent = BooleanArray(maxSubLayersMinus1)
        val subLayerLevelPresent = BooleanArray(maxSubLayersMinus1)

        for (i in 0 until maxSubLayersMinus1) {
            subLayerProfilePresent[i] = br.readBits(1) == 1
            subLayerLevelPresent[i] = br.readBits(1) == 1
        }

        if (maxSubLayersMinus1 > 0) {
            repeat(8 - maxSubLayersMinus1) {
                br.readBits(2) // reserved_zero_2bits
            }
        }

        for (i in 0 until maxSubLayersMinus1) {
            if (subLayerProfilePresent[i]) {
                br.readBits(2)
                br.readBits(1)
                br.readBits(5)
                br.readBits(32)
                br.readBits(48)
            }
            if (subLayerLevelPresent[i]) {
                br.readBits(8)
            }
        }

        Log.i(
            "HEVC-SPS",
            "profile_idc=$profileIdc level_idc=$levelIdc"
        )
    }

    private fun hevcChroma(idc: Int) =
        when (idc) {
            0 -> "Monochrome"
            1 -> "4:2:0"
            2 -> "4:2:2"
            3 -> "4:4:4"
            else -> "Unknown"
        }
    private data class ProfileTierInfo(
        val profileIdc: Int,
        val levelIdc: Int
    )

    private fun parseProfileTierLevelAndReturn(
        br: BitReader,
        maxSubLayersMinus1: Int
    ): ProfileTierInfo {

        br.readBits(2) // general_profile_space
        br.readBits(1) // general_tier_flag
        val profileIdc = br.readBits(5)

        br.readBits(32) // general_profile_compatibility_flags
        br.readBits(48) // general_constraint_indicator_flags
        val levelIdc = br.readBits(8)

        val subLayerProfilePresent = BooleanArray(maxSubLayersMinus1)
        val subLayerLevelPresent = BooleanArray(maxSubLayersMinus1)

        for (i in 0 until maxSubLayersMinus1) {
            subLayerProfilePresent[i] = br.readBits(1) == 1
            subLayerLevelPresent[i] = br.readBits(1) == 1
        }

        if (maxSubLayersMinus1 > 0) {
            repeat(8 - maxSubLayersMinus1) {
                br.readBits(2) // reserved_zero_2bits
            }
        }

        for (i in 0 until maxSubLayersMinus1) {
            if (subLayerProfilePresent[i]) {
                br.readBits(2)
                br.readBits(1)
                br.readBits(5)
                br.readBits(32)
                br.readBits(48)
            }
            if (subLayerLevelPresent[i]) {
                br.readBits(8)
            }
        }

        return ProfileTierInfo(
            profileIdc = profileIdc,
            levelIdc = levelIdc
        )
    }


    fun removeEmulationBytes(data: ByteArray): ByteArray {
        val out = ArrayList<Byte>()
        var i = 0
        while (i < data.size) {
            if (i + 2 < data.size && data[i] == 0.toByte()
                && data[i + 1] == 0.toByte()
                && data[i + 2] == 3.toByte()
            ) {
                out.add(0)
                out.add(0)
                i += 3
            } else {
                out.add(data[i])
                i++
            }
        }
        return out.toByteArray()
    }


}
