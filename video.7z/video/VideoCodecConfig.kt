package com.example.transition.video

sealed class VideoCodecConfig {
    abstract val width: Int
    abstract val height: Int
}

data class AvcConfig(
    val profile: Int,
    val level: Int,
    override val width: Int,
    override val height: Int,
    val sps: ByteArray,
    val pps: ByteArray
) : VideoCodecConfig()

data class HevcConfig(
    val profile: Int,
    val level: Int,
    override val width: Int,
    override val height: Int,
    val vps: ByteArray?,
    val sps: ByteArray,
    val pps: ByteArray
) : VideoCodecConfig()


data class AvcSpsInfo(
    val spsId: Int,
    val profileIdc: Int,
    val levelIdc: Int,
    val chromaFormatIdc: Int,
    val chromaFormat: String,
    val width: Int,
    val height: Int,
    val frameMbsOnlyFlag: Int
)


data class HevcSpsInfo(
    val spsId: Int,
    val profileIdc: Int,
    val levelIdc: Int,
    val chromaFormat: String,
    val width: Int,
    val height: Int,
    val maxSubLayersMinus1: Int
)

